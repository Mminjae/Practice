import getBase, { add } from './modules/02-19-module';

console.log(add(4));
console.log(getBase());
