<template>
  <div class="card card-body">
    <h2>Videos</h2>
  </div>
</template>

<script>
export default {
  name: 'Videos',
};
</script>
