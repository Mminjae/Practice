// var getTriangle = function (base, height) {
//   return (base * height) / 2;
// };

//  화살표 함수 쓰는 방법

// let getTriangle = (base, height) => {
//   return (base * height) / 2;
// };
//--------------------------------------------

let getTriangle = (base, height) => (base * height) / 2;

console.log('삼각향의 면적 : ' + getTriangle(5, 2));
