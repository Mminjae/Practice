function hello(name) {
  return name + '님, 안녕하세요?';
}

const name = hello();
console.log(name);
