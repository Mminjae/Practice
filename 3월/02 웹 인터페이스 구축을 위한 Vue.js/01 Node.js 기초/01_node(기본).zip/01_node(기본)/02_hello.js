function hello(name) {
  return name + '님, 안녕하세요?';
}

const name = hello('어피치');
// name = '라이언';
console.log(name);
